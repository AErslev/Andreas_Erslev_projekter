# ../core/events/shortcuts.py

'''
$Rev: 525 $
$LastChangedBy: micbarr $
$LastChangedDate: 2011-07-14 19:02:55 -0400 (Thu, 14 Jul 2011) $
'''

from gungame51.core.events import *
