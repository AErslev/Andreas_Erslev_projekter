# ../scripts/included/gg_teamwork/__init__.py

'''
$Rev: 563 $
$LastChangedBy: satoon101 $
$LastChangedDate: 2011-08-23 19:32:15 -0400 (Tue, 23 Aug 2011) $
'''
