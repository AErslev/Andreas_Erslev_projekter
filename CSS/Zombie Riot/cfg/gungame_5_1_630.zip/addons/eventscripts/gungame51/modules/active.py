# ../modules/active.py

'''
$Rev: 627 $
$LastChangedBy: satoon101 $
$LastChangedDate: 2012-03-27 18:28:57 -0400 (Tue, 27 Mar 2012) $
'''


# =============================================================================
# >> CLASSES
# =============================================================================
class ActiveInfo(object):
    round = False
    gungame = False
