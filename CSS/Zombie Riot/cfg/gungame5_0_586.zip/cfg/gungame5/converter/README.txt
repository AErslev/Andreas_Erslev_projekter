========================
gg_convert instructions:
========================

TO CONVERT GUNGAME3 SPAWNPOINTS TO GG5 (CSS:DM) FORMAT:
 1. Place all your GG3 spawnpoints in to ../cfg/gungame5/converter/gg3 spawnpoints/ folder.
 2. Load up your server.
 3. Enter "gg_convert 1" to load GunGame Convert.
 4. Enter "gg_convert_dm3" to convert your GunGame3 spawnpoints to GG5 format.

TO CONVERT GUNGAME4 SPAWNPOINTS TO GG5 (CSS:DM) FORMAT:
 1. Place all your GG4 spawnpoints in to ../cfg/gungame5/converter/gg4 spawnpoints/ folder.
 2. Load up your server.
 3. Enter "gg_convert 1" to load GunGame Convert.
 4. Enter "gg_convert_dm4" to convert your GunGame4 spawnpoints to GG5 format.

TO CONVERT GUNGAME3 WINNER DATABASE TO GG5 FORMAT:
 1. Place your GG3 winner database (es_gg_winners_db.txt) in to ../cfg/gungame5/converter/gg3 winners/ folder.
 2. Load up your server.
 3. Enter "gg_convert 1" to load GunGame Convert.
 4. Enter "gg_convert_winners3" to convert your GunGame3 winners in to GG5 format.

 TO CONVERT GUNGAME4 WINNER DATABASE TO GG5 FORMAT:
 1. Place your GG4 winner database (es_gg_database.txt) in to ../cfg/gungame5/converter/gg4 winners/ folder.
 2. Load up your server.
 3. Enter "gg_convert 1" to load GunGame Convert.
 4. Enter "gg_convert_winners4" to convert your GunGame4 winners in to GG5 format.