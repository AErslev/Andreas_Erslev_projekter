/*
 * binary.cpp
 *
 * Created: 08-05-2020 13:50:49
 *  Author: andre
 */ 
#include <Arduino.h>
#include "Transmitter.h"

int Transmitter::active = 0;

Transmitter::Transmitter() {
	
	modeType = '0';
	settings = '0';
	inputCheck = true;
	
}

void Transmitter::chooseMode() {
	
	settings = '0';
	
	do {
		
		modeType = ui.printMenu();
		inputCheck = ui.printInit();
		
	} while (inputCheck);
	
	switch (modeType) {
		case '1': // mode one
			this->runMode(modeOneDimmer);
			this->runMode(dimmerPWM);
			this->runMode(modeOneSwitch);
		break;
		
		case '2': // mode 2
			this->runMode(modeTwoDimmer);
			this->runMode(dimmerPWM);
			this->runMode(modeTwoSwitch);
		break;
		
		case '3': //mode 3
			ui.enterCode();
			if (UDR0 = '1') {
				Serial.println("Correct code entered!");
				settings = ui.printSettigs();
				changeModeTwo.setDimmerOn(settings);
				
				if (settings != '0') {
				settings = ui.printSettigs();
				changeModeTwo.setDimmerOff(settings);
				}
				
				if (settings != '0') {
					settings = ui.printSettigs();
					changeModeTwo.setDimmerPWM(settings, dimmerPWM);
				}
				
				if (settings != '0') {
				settings = ui.printSettigs();
				changeModeTwo.setSwitchOn(settings);
				}
				
				if (settings != '0') {
				settings = ui.printSettigs();
				changeModeTwo.setSwitchOff(settings);
				}
				
				if (settings != '0')
				changeModeTwo.collectMode(modeTwoDimmer, modeTwoSwitch);
			}
			else
				Serial.println("wrong code entered!");
		break;
		
		case '4':
			this->runMode(deactivateSwitch);
			this->runMode(deactivatePWM);
			this->runMode(deactivateDimmer);
		break;
		
	}
	
	ui.printActive();
	
}
	/* 
	For at teste om interrupts fungere, bruger vi ISR(INT2_vect) som interrupt. Dette g�r vi, da interruptet kan aktiveres af en knap (SW2) p� arduino shieldet. Her tjekkes det om interruptet er aktivt
	Ved hvert interrupt aktiveres OCR3A registret, som er i stand til at sende et enten "HIGH" eller "LOW" signal, alt afh�ngigt om bitsne er 1 eller 0 (1 for "HIGH", 0 for "LOW")
	*/
void Transmitter::runMode(char sendBits[]) {
	
	for (bits = 0; bits < 7; bits++) {
		sei(); //global interrupt enable
		if (sendBits[bits] == 1) {
			EICRB = 00000010;
		}
		else if (sendBits[bits] == 0) {
			EICRB = 00000011;
		}
		while (active == 0) {ui.printWaiting();}
		active = 0;
		ui.printBitSent();
	}
}

