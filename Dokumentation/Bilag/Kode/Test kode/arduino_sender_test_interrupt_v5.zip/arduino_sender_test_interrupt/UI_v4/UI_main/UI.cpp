/*
 * UI.cpp
 *
 * Created: 08-05-2020 11:10:22
 *  Author: andre
 */ 
/*
 * UI.cpp
 *
 * Created: 01-05-2020 14:03:54
 *  Author: andre
 */ 

#include <Arduino.h>
#include "UI.h"

UI::UI() {inputOne = '0'; inputTwo = '0'; code = '0'; waitValue = '0'; module = '1';}

char UI::printMenu() {
	
	this->serialFlush();
	PORTB = 255;
	if (inputTwo == '0') {
		Serial.write(12);
		delay(500);
		Serial.println("Hello!");
		inputTwo = '-1';
	}
		
	Serial.println("What would you like to do?");
	Serial.println("- 1. Choose mode one");
	Serial.println("- 2. Choose mode two");
	Serial.println("- 3. Change mode two");
	Serial.println("- 4. Deactivate Home Protection");
	Serial.print("Choice: ");
	while (1) {	
		if (Serial.available() > 0) {
			
			inputOne = Serial.read();

			if (inputOne != '0') {
				
				// Reset PuTTy konsol
				Serial.write(12);
				delay(500);
				
				return inputOne;
			}
		}
	}
}
bool UI::printInit() {
	
	if (inputOne == '1') {
		Serial.println("Mode one is initializing:");
		PORTB = 1;
		return false;
	}
	else if(inputOne == '2') {
		Serial.println("Mode two is initializing:");
		PORTB = 0b00000010;
		return false;
	}
	else if(inputOne == '3') {
		Serial.println("Change your settings for mode two:");
		PORTB = 0b00000100;
		return false;
	}	
	else if(inputOne == '4') {
		PORTB = 0b00001000;
		Serial.println("Home Protection is deactivating");
		return false;
	}
	else {
		this->printWrongInput();
		return true;
	}
}
void UI::enterCode() {
	this->serialFlush();
	Serial.println("Enter code on DE2-board: ");
	
	for (int timer = 1; timer <= 10; timer++) {
		Serial.print(timer); Serial.print(" ");
		delay(100);
	}
	
}
char UI::printSettigs() {
		
	switch (module) {
		case '1':
			Serial.println("Choose what time the Dimmer should turn on: ");
		break;
		
		case '2':
			Serial.println("Choose what time the Dimmer should turn off: ");
		break;		
		
		case '3':
		Serial.println("Chose intensity for dimmer: ");
		break;
		
		case '4':
			Serial.println("Choose what time the Switch should turn on: ");
		break;
		
		case '5':
			Serial.println("Choose what time the Switch should turn off: ");
		break;
				
	}
	
	Serial.println("Options:");
	
	if (module != '3') {
		Serial.println("- 1. 1 hour ");
		Serial.println("- 2. 2 hours ");
		Serial.println("- 3. 3 hours ");
		Serial.println("- 4. 4 hours ");
		Serial.println("- 0. Go back");
	}
	
	else if (module == '3') {
		Serial.println("- 1. = 10%");
		Serial.println("- 2. = 20%");
		Serial.println("- 3. = 30%");
		Serial.println("- 4. = 40%");
		Serial.println("- 5. = 50%");
		Serial.println("- 6. = 60%");
		Serial.println("- 7. = 70%");
		Serial.println("- 8. = 80%");
		Serial.println("- 9. = 90%");
		Serial.println("- 10 = 100%");
		Serial.println("- 0. Go back");
	}
	Serial.print("Choice: ");
	
	this->serialFlush();
	
	while (1) {
		if (Serial.available() > 0) {
			
			inputTwo = Serial.read();
			
			if (inputTwo != '-1') {
				module++;
				Serial.write(12);
				delay(500);
				return inputTwo;
			}
		}
	}
}
void UI::printWaiting() {
	
	if (waitValue > '7' ) {
		waitValue = '0';
		Serial.print("\n- - - - - - - - -\n");
	}
	else if (waitValue == '4' ) {
		Serial.print("\n- - - - - - - - -\n");
		waitValue++;
	}
	else
		waitValue++;
		
	Serial.print("Waiting ");
	for (char dots = 0; dots < 3; dots++) {
		_delay_ms(300);
		Serial.print(". ");
	}
	
	_delay_ms(500);
	
}
void UI::printActive() {
	
	// Reset PuTTy konsol
	Serial.write(12);
	delay(500);
	
	if (inputOne == '1') 
		Serial.println("Mode one is now active");
	else if(inputOne == '2') 
		Serial.println("Mode two is now active");
	else if (inputOne == '3' && inputTwo != '0')
		Serial.println("Mode 2 is now changed");
	else if (inputOne == '4')
		Serial.println("Home Protection is now deactivated");
	else if (inputTwo == '0')
		Serial.println("Mode two was not changed");
	
	Serial.println("- - - - - - - - - - - ");
	PORTB = 0;
	inputOne = '0'; inputTwo = '-1'; waitValue = '0'; module = '1';
	
	
}
void UI::printBitSent() {
	Serial.print("\n\nBit sent!\n");
	_delay_ms(250);
	waitValue = '0';
}
void UI::printWrongInput() const {
	
	Serial.println("You have chosen an input, that is not valid. Try again.");
	
}
void UI::serialFlush() const {
	_delay_ms(500);
	while(Serial.available() > 0) {
		char buffer = Serial.read();
	}
}