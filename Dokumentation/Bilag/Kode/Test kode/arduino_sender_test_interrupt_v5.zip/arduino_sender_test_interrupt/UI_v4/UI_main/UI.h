/*
 * IncFile1.h
 *
 * Created: 01-05-2020 13:50:34
 *  Author: andre
 */ 

#ifndef UI_H
#define UI_H

class UI {
	
public:
	UI();
	char printMenu();
	char printSettigs();
	void enterCode();
	bool printInit();
	void printWaiting();
	void printActive();
	void printBitSent();
	void printWrongInput() const;
	void serialFlush() const;
	
private:
	char inputOne, inputTwo, code, waitValue, module;
	
	};

#endif /* INCFILE1_H_ */