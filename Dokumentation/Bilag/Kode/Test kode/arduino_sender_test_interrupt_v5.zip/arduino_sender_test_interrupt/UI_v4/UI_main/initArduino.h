/*
 * initArduino.h
 *
 * Created: 18-05-2020 14:04:43
 *  Author: andre
 */ 

#ifndef INITARDUINO_H_
#define INITARDUINO_H_

#include <avr/interrupt.h>

void initPortB();
void initInterrupt();
void initCTC();



#endif /* INITARDUINO_H_ */