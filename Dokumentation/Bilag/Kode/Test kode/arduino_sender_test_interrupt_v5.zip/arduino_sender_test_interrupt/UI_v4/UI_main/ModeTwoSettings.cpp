/*
 * modeThree.cpp
 *
 * Created: 14-05-2020 10:50:05
 *  Author: andre
 */ 

#include "ModeTwoSettings.h"

ModeTwoSettings::ModeTwoSettings() {};

void ModeTwoSettings::setDimmerOn(char settings) {

	switch (settings) {
		case '1':
		dimmerOn[0] = 0;
		dimmerOn[1] = 0;
		break;
		
		case '2':
		dimmerOn[0] = 1;
		dimmerOn[1] = 0;
		break;
		
		case '3':
		dimmerOn[0] = 0;
		dimmerOn[1] = 1;
		break;
		
		case '4':
		dimmerOn[0] = 1;
		dimmerOn[1] = 1;
		break;
	}
}

void ModeTwoSettings::setDimmerOff(char settings) {

	switch (settings) {
		case '1':
		dimmerOff[0] = 0;
		dimmerOff[1] = 0;
		break;
		
		case '2':
		dimmerOff[0] = 1;
		dimmerOff[1] = 0;
		break;
		
		case '3':
		dimmerOff[0] = 0;
		dimmerOff[1] = 1;
		break;
		
		case '4':
		dimmerOff[0] = 1;
		dimmerOff[1] = 1;
		break;
	}
}

void ModeTwoSettings::setDimmerPWM(char settings, char dimmerPWM[]) {

	switch (settings) {
		case '1':
		dimmerPWM[2] = 0;
		dimmerPWM[3] = 0;
		dimmerPWM[4] = 0;
		dimmerPWM[5] = 1;
		break;
		
		case '2':
		dimmerPWM[2] = 0;
		dimmerPWM[3] = 0;
		dimmerPWM[4] = 1;
		dimmerPWM[5] = 0;
		break;
		
		case '3':
		dimmerPWM[2] = 0;
		dimmerPWM[3] = 0;
		dimmerPWM[4] = 1;
		dimmerPWM[5] = 1;
		break;
		
		case '4':
		dimmerPWM[2] = 0;
		dimmerPWM[3] = 1;
		dimmerPWM[4] = 0;
		dimmerPWM[5] = 0;
		break;
		
		case '5':
		dimmerPWM[2] = 0;
		dimmerPWM[3] = 1;
		dimmerPWM[4] = 0;
		dimmerPWM[5] = 1;
		break;
		
		case '6':
		dimmerPWM[2] = 0;
		dimmerPWM[3] = 1;
		dimmerPWM[4] = 1;
		dimmerPWM[5] = 0;
		break;
		
		case '7':
		dimmerPWM[2] = 0;
		dimmerPWM[3] = 1;
		dimmerPWM[4] = 1;
		dimmerPWM[5] = 1;
		break;
		
		case '8':
		dimmerPWM[2] = 1;
		dimmerPWM[3] = 0;
		dimmerPWM[4] = 0;
		dimmerPWM[5] = 0;
		break;
		
		case '9':
		dimmerPWM[2] = 1;
		dimmerPWM[3] = 0;
		dimmerPWM[4] = 0;
		dimmerPWM[5] = 1;
		break;
		
		case '10':
		dimmerPWM[2] = 1;
		dimmerPWM[3] = 0;
		dimmerPWM[4] = 1;
		dimmerPWM[5] = 0;
		break;
		
	}
}

void ModeTwoSettings::setSwitchOn(char settings) {

	switch (settings) {
		case '1':
		switchOn[0] = 0;
		switchOn[1] = 0;
		break;
		
		case '2':
		switchOn[0] = 1;
		switchOn[1] = 0;
		break;
		
		case '3':
		switchOn[0] = 0;
		switchOn[1] = 1;
		break;
		
		case '4':
		switchOn[0] = 1;
		switchOn[1] = 1;
		break;
	}
}

void ModeTwoSettings::setSwitchOff(char settings) {

	switch (settings) {
		case '1':
		switchOff[0] = 0;
		switchOff[1] = 0;
		break;
		
		case '2':
		switchOff[0] = 1;
		switchOff[1] = 0;
		break;
		
		case '3':
		switchOff[0] = 0;
		switchOff[1] = 1;
		break;
		
		case '4':
		switchOff[0] = 1;
		switchOff[1] = 1;
		break;
	}
}

void ModeTwoSettings::collectMode(char dimmerMode[], char switchMode[]) {
	
	for (int n = 2; n < 6; n++) {
		if (n < 4)
			dimmerMode[n] = dimmerOn[n];
		else if (n < 6)
			dimmerMode[n] = dimmerOff[n - 2];
	}
	
	for (int n = 2; n < 6; n++) {
		if (n < 4)
			switchMode[n] = switchOn[n];
		else if (n < 6)
			switchMode[n] = switchOff[n - 2];
	}
	
}