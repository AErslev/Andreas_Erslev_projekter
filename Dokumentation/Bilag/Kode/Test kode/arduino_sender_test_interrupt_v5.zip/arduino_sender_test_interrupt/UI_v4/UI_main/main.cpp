﻿/*Begining of Auto generated code by Atmel studio */
#include <Arduino.h>

/*End of auto generated code by Atmel studio */

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

// Tilføj biblioteker
#include "Transmitter.h"
#include "initArduino.h"

//Beginning of Auto generated function prototypes by Atmel Studio
//End of Auto generated function prototypes by Atmel Studio

void setup() {
	Serial.begin(9600); // opens serial port, sets data rate to 9600 bps
}

//Set hoved objekt
Transmitter startMode;

//Set interrupts
ISR(INT2_vect) {
	
	OCR3A = 65;
	EICRB = 0b00000001;
	Transmitter::active = 1;
	delay(1);
	cli(); //global interrupt disable
} 

void loop() {
	
	initPortB();
	initInterrupt();
	initCTC();
	
	do {
	startMode.chooseMode();
	} while (1);
}
