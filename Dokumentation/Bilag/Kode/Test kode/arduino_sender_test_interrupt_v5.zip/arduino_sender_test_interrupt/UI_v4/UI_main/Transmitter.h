/*
 * Transmitter.h
 *
 * Created: 14-05-2020 12:11:54
 *  Author: andre
 */ 

#ifndef TRANSMITTER_H_
#define TRANSMITTER_H_

#include "UI.h"
#include "ModeTwoSettings.h"

class Transmitter {
	
	public:
	Transmitter();
	void chooseMode();
	void runMode(char[]);
	static int active;
	private:
	
	UI ui;
	ModeTwoSettings changeModeTwo;
	
	bool inputCheck;
	
	char
		
	modeType, settings, wait, bits,
	
	modeOneDimmer[7] = {0, 0, 0, 1, 1, 1, 1},
	modeOneSwitch[7] = {0, 1, 1, 1, 0, 0, 1},
	
	modeTwoDimmer[7] = {0, 0, 0, 1, 1, 1, 1},
	modeTwoSwitch[7] = {0, 1, 1, 1, 0, 0, 1},
	
	dimmerPWM[7] = {0, 0, 1, 0, 1, 0, 1},
	
	deactivateDimmer[7] = {0, 0, 0, 0, 0, 0, 1},
	deactivatePWM[7] = {0, 0, 0, 0, 0, 0, 1},
	deactivateSwitch[7] = {0, 1, 0, 0, 0, 0, 1};
};
#endif /* TRANSMITTER_H_ */