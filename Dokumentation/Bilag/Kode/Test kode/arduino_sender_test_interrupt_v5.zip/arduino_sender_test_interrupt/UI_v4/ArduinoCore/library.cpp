/*
 * ArduinoCore.cpp
 *
 * Created: 08-05-2020 11:08:32
 * Author : andre
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

