/*
 * initArduino.cpp
 *
 * Created: 18-05-2020 14:03:43
 *  Author: andre
 */ 

#include "initArduino.h"

void initPortB() {
		DDRB = 255; // Open Port B
		PORTB = 0; // Set PortB to 0
}

void initInterrupt() {
	EIMSK = 0b00010000;    // External interupt, INT4
	EICRB = 0b00000001;    // low level INT interrupt, default
}

void initCTC() {
	//    Mode = 4 (CTC)
	//    Set OC3A on match down counting / Clear OC3A on match counting
	//    Clock prescaler = 1
	TCCR3A = 0b11000000;
	TCCR3B = 0b00001001;
}