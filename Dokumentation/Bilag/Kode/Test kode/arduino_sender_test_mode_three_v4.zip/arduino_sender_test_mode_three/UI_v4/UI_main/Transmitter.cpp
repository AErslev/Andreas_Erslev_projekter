/*
 * binary.cpp
 *
 * Created: 08-05-2020 13:50:49
 *  Author: andre
 */ 
#include <Arduino.h>
#include "Transmitter.h"

Transmitter::Transmitter() {
	
	modeType = '0';
	settings = '0';
	inputCheck = true;
	
}

void Transmitter::chooseMode() {
	
	settings = '0';
	
	do {
		
		modeType = ui.printMenu();
		inputCheck = ui.printInit();
		
	} while (inputCheck);
	
	switch (modeType) {
		case '1': // mode one
			this->runMode(modeOneDimmer);
			this->runMode(dimmerPWM);
			this->runMode(modeOneSwitch);
		break;
		
		case '2': // mode 2
			this->runMode(modeTwoDimmer);
			this->runMode(dimmerPWM);
			this->runMode(modeTwoSwitch);
		break;
		
		case '3': //mode 3
			ui.enterCode();
			if (UDR0 = '1') {
				Serial.println("Correct code entered!");
				settings = ui.printSettigs();
				changeModeTwo.setDimmerOn(settings);
				
				if (settings != '0') {
				settings = ui.printSettigs();
				changeModeTwo.setDimmerOff(settings);
				}
				
				if (settings != '0') {
					settings = ui.printSettigs();
					changeModeTwo.setDimmerPWM(settings, dimmerPWM);
				}
				
				if (settings != '0') {
				settings = ui.printSettigs();
				changeModeTwo.setSwitchOn(settings);
				}
				
				if (settings != '0') {
				settings = ui.printSettigs();
				changeModeTwo.setSwitchOff(settings);
				}
				
				if (settings != '0')
				changeModeTwo.collectMode(modeTwoDimmer, modeTwoSwitch);
			}
			else
				Serial.println("wrong code entered!");
		break;
		
		case '4':
			this->runMode(deactivateSwitch);
			this->runMode(deactivatePWM);
			this->runMode(deactivateDimmer);
		break;
		
	}
	
	/* Her testes der for, om v�rdierne i modeTwo �ndre sig, efter modeThree har �ndret p� v�rdierne . modeThree k�rer alts� f�rst og �ndre v�rdierne i mode 2.
	V�rdierne for standart modeTwo er de samme som for modeOne. Derfor k�res arrayet for modeOne f�rst. Herefter vil det �ndrede modeTwo blive printet med nye v�rdier.
	Der fokuseres kun p� dimmer arrayet.
	Der formodes at i vores test eksemple dette output: 
	modeOne dimmer: 0, 0, 0, 1, 1, 1, 1
	modeTwo dimmer: 0, 0, 0, 0, 0, 0, 1
	*/
	
	ui.printActive();
	
	for (int test = 0; test < 7; test++) {
		if (modeOneDimmer[test] == 1)
		Serial.print("1, ");
		
		else if (modeOneDimmer[test] == 0)
		Serial.print("0, ");
	}
	
	Serial.println("\n");
	
	for (int test = 0; test < 7; test++) {
		if (modeTwoDimmer[test] == 1)
		Serial.print("1, ");
		
		else if (modeTwoDimmer[test] == 0)
		Serial.print("0, ");
	}
	
}
/* OBS OBS OBS! SLET K*/
void Transmitter::runMode(char sendBits[]) {
	
	for (bits = 0; bits < 7; bits++) {
	
		sei(); //global interrupt enable
		if (sendBits[bits] == 1) {
			EICRB = 00000010;
		}
		else if (sendBits[bits] == 0) {
			EICRB = 00000011;
		}
		while ((PCIFR & 1) == 0) {ui.printWaiting();}
		ui.printBitSent();
	}
}

