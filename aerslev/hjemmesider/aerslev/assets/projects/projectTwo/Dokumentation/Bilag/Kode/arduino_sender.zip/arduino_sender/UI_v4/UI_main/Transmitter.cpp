/*
 * binary.cpp
 *
 * Created: 08-05-2020 13:50:49
 *  Author: andre
 */ 
#include <Arduino.h>
#include "Transmitter.h"

// Constructor for Transmitter
Transmitter::Transmitter() {
	
	modeType = '0';
	settings = '0';
	inputCheck = true;
	
}

// chooseMode - Hovedprogram
void Transmitter::chooseMode() {
	
	// S�rger for at settings for mode 3 ikke er pr�defineret
	settings = '0';
	
	// Printer menu, tager imod bruger input og tjekker om inputtet er validt
	do {
		
		modeType = ui.printMenu();
		inputCheck = ui.printInit();
	
	} while (inputCheck);
	
	// 	Bestemmer hvilket mode der skal k�res, ud fra brugerens tidligere input
	switch (modeType) {
		case '1': // mode one
			this->runMode(modeOneDimmer);
			this->runMode(dimmerPWM);
			this->runMode(modeOneSwitch);
		break;
		
		case '2': // mode two
			this->runMode(modeTwoDimmer);
			this->runMode(dimmerPWM);
			this->runMode(modeTwoSwitch);
		break;
		
		case '3': //mode three
			ui.enterCode();
			// UDR0 s�rger for at koden kun vil k�re, hvis kodeordet fra DE2-boardet er rigtigt.
			if (UDR0 = '1') {
				Serial.println("Correct code entered!");
				settings = ui.printSettigs(); // Printer valgmuligheder og tager imod input fra brugeren
				changeModeTwo.setDimmerOn(settings); // �ndre v�rdien for mode two
				
				if (settings != '0') { // Hvis settings == '0', vil der ikke �ndres p� flere v�rdier. Brugeren afslutter alts� mode three
				settings = ui.printSettigs();
				changeModeTwo.setDimmerOff(settings);
				}
				
				if (settings != '0') {
					settings = ui.printSettigs();
					changeModeTwo.setDimmerPWM(settings, dimmerPWM);
				}
				
				if (settings != '0') {
				settings = ui.printSettigs();
				changeModeTwo.setSwitchOn(settings);
				}
				
				if (settings != '0') {
				settings = ui.printSettigs();
				changeModeTwo.setSwitchOff(settings);
				}
				
				// Samler de ny v�rdier og skaber nye arrays for mode two
				if (settings != '0')
				changeModeTwo.collectMode(modeTwoDimmer, modeTwoSwitch);
			}
			else
				Serial.println("wrong code entered!");
		break;
		
		// Deaktivere det aktuelle mode
		case '4':
			this->runMode(deactivateSwitch);
			this->runMode(deactivatePWM);
			this->runMode(deactivateDimmer);
		break;
		
	}
	
	ui.printActive();
	
}

void Transmitter::runMode(char sendBits[]) {
	
	// S�rger for at sende alle bits fra arraysne videre
	for (bits = 0; bits < 7; bits++) {
	
		sei(); //global interrupt enable
		// Bestemmer m�den (1 eller 0) hvorp� det aktuelle bit skal sendes - her sendes 1
		if (sendBits[bits] == 1) {
			EICRB = 00000010;
		}
		// Bestemmer m�den (1 eller 0) hvorp� det aktuelle bit skal sendes - her sendes 0
		else if (sendBits[bits] == 0) {
			EICRB = 00000011;
		}
		// Venter p� interrupt der skal sende bitsne videre
		while ((PCIFR & 1) == 0) {ui.printWaiting();} // Printer en "waiting" besked til brugeren, for at vise der sendes data
		// Fort�ller brugeren at data er blevet sendt
		ui.printBitSent();
	}
}

