/*
 * IncFile1.h
 *
 * Created: 01-05-2020 13:50:34
 *  Author: andre
 */ 

#ifndef UI_H
#define UI_H

class UI {
	
public:
	UI();
	// Printer menu
	char printMenu();
	// Printer brugerens �nskede settings for moed two
	char printSettigs();
	// Beder brugeren om kodeord
	void enterCode();
	// Tjekker om real v�rdi er valgt og printer besked om initialisering eller forkert input
	bool printInit();
	// Printer en vente besked til brugeren
	void printWaiting();
	// Giver brugeren besked om at det valgte mode nu er aktivt / mode two er �ndret / aktuelle mode er deaktiveret
	void printActive();
	// Fort�ller brugeren at et bit er sendt
	void printBitSent();
	// Printer besked om forkert input
	void printWrongInput() const;
	// "Udskylder" alle bruger inputs og g�r klar til at modtage nye
	void serialFlush() const;
	
private:
	char inputOne, inputTwo, code, waitValue, module;
	
	};

#endif /* INCFILE1_H_ */