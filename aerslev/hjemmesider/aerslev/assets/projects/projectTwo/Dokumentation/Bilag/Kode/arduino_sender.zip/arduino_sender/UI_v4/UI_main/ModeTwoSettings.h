/*
 * modeThree.h
 *
 * Created: 14-05-2020 10:50:31
 *  Author: andre
 */ 


#ifndef MODETHREE_H_
#define MODETHREE_H_

class ModeTwoSettings {
	
public:
	ModeTwoSettings();
	// �ndre p� 2 v�rdier i et array
	void setDimmerOn(char);
	// �ndre p� de v�rdier der har noget at g�re med dimmerPWM i arrayet for mode Two
	void setDimmerOff(char);
	void setDimmerPWM(char, char[]);
	void setSwitchOn(char);
	void setSwitchOff(char);
	// Samler alle arrays (On/Off) til nye arrays, som bliver til de nye arrays i mode two
	void collectMode(char[], char[]);
	
private:
	
	char
	
	dimmerOn[2],
	dimmerOff[2],
	
	switchOn[2],
	switchOff[2];
	
};



#endif /* MODETHREE_H_ */