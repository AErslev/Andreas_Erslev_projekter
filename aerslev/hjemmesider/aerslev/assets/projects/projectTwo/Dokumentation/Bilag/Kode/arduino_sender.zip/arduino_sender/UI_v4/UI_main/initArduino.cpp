/*
 * initArduino.cpp
 *
 * Created: 18-05-2020 14:03:43
 *  Author: andre
 */ 

#include "initArduino.h"

void initPortB() {
		DDRB = 255; // Open Port B
		PORTB = 0; // Set PortB to 0
}

void initInterrupt() {
	EIMSK = 0b00010000;    // External interupt, INT4
	EICRB = 0b00000001;    // low level INT interrupt, default
}

void initCTC() {
	//    Mode = 4 (CTC)
	//    Set OC3A on match down counting / Clear OC3A on match counting
	//    Clock prescaler = 1
	TCCR3A = 0b11000000;
	TCCR3B = 0b00001001;
}

void initUART() {
	// Indstillets til Normal mode
	UCSR0A = 0b00100000;
	// Ingen interrupts enabled
	// Ingen sender enabled
	// Modtager enabled
	UCSR0B = 0b00010000;
	// Asynchronous mode
	// 1 stop bit
	// Ingen paritet
	// 8-bits
	UCSR0C = 0b00000110;
	// Baud-rate = 9600
	UBRR0 = 103;
}