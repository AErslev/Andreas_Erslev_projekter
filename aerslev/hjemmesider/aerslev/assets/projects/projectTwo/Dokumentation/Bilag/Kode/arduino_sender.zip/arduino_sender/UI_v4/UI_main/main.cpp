﻿// Tilføj biblioteker
#include <Arduino.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include "Transmitter.h"
#include "initArduino.h"

// Initialisering af Arduino.h 
void setup() {
	Serial.begin(9600); 
}

//Set hovede objekt
Transmitter startMode;

//Set interrupt klar. Interruptet skal kunne sende et signal ud, enten 1 (HIGH) eller 0 (LOW)
ISR(INT4_vect) {
	// Sender et signal (enter 1 (HIGH) eller 0 (LOW))
	OCR3A = 65;
	EICRB = 0b00000001;
	delay(1);
	cli(); //global interrupt disable
} 

void loop() {
	
	//Initialisering af arduino egenskaber
	initUART();
	initPortB();
	initInterrupt();
	initCTC();
	
	do {
	// Start choose mode hovede program
	startMode.chooseMode();
	} while (1);
}
