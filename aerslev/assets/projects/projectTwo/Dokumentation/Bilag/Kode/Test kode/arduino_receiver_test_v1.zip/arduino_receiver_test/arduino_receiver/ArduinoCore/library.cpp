/*
 * ArduinoCore.cpp
 *
 * Created: 15-05-2020 14:18:10
 * Author : andre
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

