﻿/*Begining of Auto generated code by Atmel studio */
#include <Arduino.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "Receiver.h"

/*End of auto generated code by Atmel studio */

//Beginning of Auto generated function prototypes by Atmel Studio
//End of Auto generated function prototypes by Atmel Studio

void setup() {
  // put your setup code here, to run once:
	Serial.begin(9600); // opens serial port, sets data rate to 9600 bps

}

static volatile char loadBits[7];
static volatile int count = 0;

ISR(INT2_vect) {
	
	// Rising edge
	
	//if (digitalRead(2) == 1) // Set signal fra envalope
	//loadBits[count++] = '1';
	//
	//else if (digitalRead(2) == 0) // Set signal fra envalope
	//loadBits[count++] = '0';
	
	loadBits[count++] = count;
	
	cli();
	delay(50000);
	sei(); 
}

void loop() {

	DDRB = 255;
	PORTB = 5;
	char sendBits[7];
	initInterrupt();
	initPWM();

	while (1) {
		// Activate interrupt
		sei(); //global interupt enable
		while (count < 7) {	
			switch (count) {
				case 1: PORTB = 0b00000001;
				break;
				case 2: PORTB = 0b00000010;
				break;
				case 3: PORTB = 0b00000100;
				break;
				case 4: PORTB = 0b00001000;
				break;
				case 5: PORTB = 0b00010000;
				break;
				case 6: PORTB = 0b00100000;
				break;
				case 7: PORTB = 0b01000000;
				break;
				case 8: PORTB = 0b10000000;
				break;
			}
		}
		// Deaktivate interrupt
		cli(); //global interrupt disable
		
		for (int n = 0; n < 7; n++) {
			sendBits[n] = loadBits[n];
			PORTB = 0b10101010;
			delay(25000);
			PORTB = 0b01010101;
			delay(25000);
			}
			
		for (int n = 0; n < 7; n++) {
			switch (sendBits[n]) {
				case 0: PORTB = 0b00000000;
				break;
				case 1: PORTB = 0b00000001;
				break;
				case 2: PORTB = 0b00000010;
				break;
				case 3: PORTB = 0b00000100;
				break;
				
			}
			
			switch (loadBits[n]) {
				case 4: PORTB = 0b00001000;
				break;
				case 5: PORTB = 0b00010000;
				break;
				case 6: PORTB = 0b00100000;
				break;
				case 7: PORTB = 0b01000000;
				break;
				
			}		
				
			delay(50000);
		}
			
		inputReader(sendBits);
		count = 0;
		PORTB = 0;
		
	}

}
