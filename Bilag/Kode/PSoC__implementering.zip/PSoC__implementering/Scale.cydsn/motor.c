#include "project.h"
#include <stdio.h>
#include <stdlib.h>

#include "motor.h"

int Speed = 15;
int IN1, IN2 = 0;

void handleByteReceived(uint8_t byteReceived)
{
    switch(byteReceived)
    {
        case '1' :
        {
            start();
        }
        break;
        case '0' :
        {
            stop();
        }
        break;
        default :
        {
        }
        break;
    }
}

void start()
{
    PWM_1_WriteCompare(Speed);
    
    IN1 = 1;
    IN2 = 0;
    
    Pin_1_Write(IN1);
    Pin_2_Write(IN2);
    //UART_PutString(" - Motor start\r\n");
}

void stop()
{
    IN1 = 0;
    IN2 = 0;
    
    Pin_1_Write(IN1);
    Pin_2_Write(IN2);
    //UART_PutString(" - Motor stop\r\n");
}