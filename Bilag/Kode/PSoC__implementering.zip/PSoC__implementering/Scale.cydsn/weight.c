#include "project.h"
#include <stdio.h>
#include <stdlib.h>

#include "weight.h"

uint16_t setProduct(uint16_t weight) {
 
    char uartBuffer[256];
    
    uint16_t product = 0;
    uint16_t aeble = 1;
    uint16_t smoer = 2;
    uint16_t rugbroed = 3;
    
    // Varer sættes klar til transmittering
    if (weight > 0 && weight <= 300) {
        
        // Sætter produkt type
        product = aeble;
        
        // Klargøre tekst til print i konsol
        //snprintf(uartBuffer, sizeof(uartBuffer), "Aeble er tilfoejet til kurven\r\n");
        
    }
    
    // Varer sættes klar til transmittering
    else if (weight > 300 && weight <= 600) {
        
        // Sætter produkt type
        product = smoer;

        // Klargøre tekst til print i konsol
        //snprintf(uartBuffer, sizeof(uartBuffer), "Smoer er tilfoejet til kurven\r\n");
        
    }
    
    // Varer sættes klar til transmittering
    else if (weight > 600 && weight <= 900) {
        
        // Sætter produkt type
        product = rugbroed;

        // Klargøre tekst til print i konsol
        //snprintf(uartBuffer, sizeof(uartBuffer), "Rugbroed er tilfoejet til kurven\r\n");
        
    }
    
    // Der er ikke målt nogen varer, og derfor sendes ingen data
    else {
        
        // Informere om at der ikke er et produkt registreret 
        product = 0;

        // Klargøre tekst til print i konsol
        //snprintf(uartBuffer, sizeof(uartBuffer), "Der er ikke noget produkt registreret!\r\n");
        
    }
    
    UART_PutString(uartBuffer);
    
    return product;
    
}

float voltToGram(uint16_t volt) {
    
    float gram = 0;
    
    // Når der udføres et loop stiger antal millivolt med 1 og gram stiger dermed 0.8, som er hældningskoefficienten.
    // Loop starter på, 0x31f (0 punkt for vægt), som svarer til 799 i decimaltal
    for (uint16_t convert = 810; convert < volt; convert++) {
        gram += 0.8;           
    }
    
    return gram;
    
}