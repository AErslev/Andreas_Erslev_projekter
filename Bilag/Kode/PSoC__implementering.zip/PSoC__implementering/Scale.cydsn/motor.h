#include "project.h"

void handleByteReceived(uint8_t byteReceived);
void start(void);
void stop(void);