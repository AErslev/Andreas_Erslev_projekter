float voltToGram(uint16_t volt);
uint16_t setProduct(uint16_t weight);