#include "project.h"
#include <stdio.h>
#include <stdlib.h>

#include "weight.h"
#include "motor.h"

CY_ISR_PROTO(ISR_UART_rx_handler);

int main(void)
{
    
    CyGlobalIntEnable;
    
    char uartBuffer[256];
    
    isr_uart_rx_StartEx(ISR_UART_rx_handler);
    UART_Start();
    PWM_1_Start();
    ADC_SAR_Start();
    ADC_SAR_StartConvert();
    
    float resultGram = 0;
    uint16_t result = 0;
    uint16_t checkWeight = 0;
    uint16_t product = 0;
    
    UART_PutString("Vaegt og motor er initialiseret og klar til brug\r\n");
    
    for(;;)
    {
        // Tjekker vægt - tjekker 6 gange med 0.25 sekunders mellemrum
        for (uint8_t stabilisere = 0; stabilisere < 6; stabilisere++) {
        /* Place your application code here. */
            if (ADC_SAR_IsEndConversion(ADC_SAR_WAIT_FOR_RESULT))
            {
                // Tjekker spændingen over vægten
                result = ADC_SAR_GetResult16();
                
                // Funktion bruges til konvertering
                resultGram = voltToGram(result);

                UART_PutString(uartBuffer);
                
                // Delay på 0.5 sekunder mellem resultat og transmitering af data
                CyDelay(250);

            }
        }
        
        //snprintf(uartBuffer, sizeof(uartBuffer), "Maalt resultat -  Volt: %dmV Gram: %2.fg\r\n", result, resultGram);
        //UART_PutString(uartBuffer);
        
        // Tjek om der er sket en ændring af vægt. Hvis der sker en ændrig på plus/mins 5 gram, kan et nyt produkt tilføjes i kurven
        if (resultGram > checkWeight + 10 || resultGram < checkWeight - 10) {
            
            // Aktivere mulighed for at ændre produkt type
            product = setProduct(resultGram);
            
            snprintf(uartBuffer, sizeof(uartBuffer), "%d\r\n", product);
            checkWeight = resultGram;
            
            //snprintf(uartBuffer, sizeof(uartBuffer), "Check: %d - result: %2.f\r\n", checkWeight, resultGram);
        
        }        
    
    }
    
}

CY_ISR(ISR_UART_rx_handler)
{
    uint8_t bytesToRead = UART_GetRxBufferSize();
    while (bytesToRead > 0)
    {
        uint8_t byteReceived = UART_ReadRxData();
        UART_WriteTxData(byteReceived); // echo back

        handleByteReceived(byteReceived);

        bytesToRead--;
    }
}