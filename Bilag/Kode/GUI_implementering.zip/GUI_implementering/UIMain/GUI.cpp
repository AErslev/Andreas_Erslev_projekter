#include "smartWagon.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>  

std::string state = "wait";
char vaegt_name;

void sendGroceryListToGUI(SmartWagon& wagon, uWS::Hub& hub)
{
    // Sender den fulde indkøbslisten til GUI hjemmesiden
    const std::vector<Product>& list = wagon.getGroceryList();

    // Sender listen til GUI, så GUI kan vise listen
    std::ostringstream ss;
    ss << "GroceryList:";
    double sum = 0;
    // For hvert produkt i listen, skrives navn og pris til ostream "GroceryList"
    for(unsigned long i = 0; i < list.size(); i++)
    {
        ss << "Vare: " << list[i].name_ << std::fixed << std::setprecision(2) 
            << "          Pris: " << list[i].price_ << " kr." << "#";
        sum = sum + list[i].price_;

        if(i != list.size() - 1)
        {
            ss << "Det nuværende beløb: " << std::fixed << std::setprecision(2) 
                << sum << " kr." << "#";
        }
    }
    ss << "Det totale beløb: " << std::fixed << std::setprecision(2) 
                << wagon.totalSum() << " kr.";

    // Sender hele indkøbslisten til GUI, så GUI kan vise indkøbslisten
    hub.broadcast(ss.str().c_str(),ss.str().length(), uWS::OpCode::TEXT);
}

struct Data
{

  uWS::Hub& hub;
  SmartWagon& wagon;
  
  void operator()(uWS::WebSocket<uWS::SERVER> *ws,
	char *message, size_t length,
	uWS::OpCode opCode) {

    if (std::string(message, length) == "start") {
        std::cout << "Initializes Smart Wagon" << std::endl;
        state = "on";

        // sende 1 til /dev/ttyS0
        //int length = 1;
        int fd = open("/dev/ttyS0", O_WRONLY);
        write(fd, "1", 1); 
        close(fd);       
    }
    else if(std::string(message, length) == "addProduct")
    {
        std::cout << "Adds product to grocery list" << std::endl;

        //hente vægten fra veje-cellen og gemmer det i en variabel, som sendes med til addToGroceryList
       int fd = open("/dev/ttyS0", O_RDONLY);
       ssize_t size = read(fd, &vaegt_name, 1);
       if(vaegt_name == '1')
       {
           wagon.addToGroceryList("aeble");
       }
       else if(vaegt_name == '2')
       {
            wagon.addToGroceryList("smoer");
       }
       else if (vaegt_name == '3')
       {
            wagon.addToGroceryList("rugbroed");
       }

        // kalder sendGroceryListToGUI(SmartWagon, WS::Hub)
        sendGroceryListToGUI(wagon, hub);
        //vaegt_name = 0;
        close(fd); 
    }
    else if(std::string(message, length) == "removeProduct")
    {
        std::cout << "Removes product from grocery list" << std::endl;
       
       
        //hente vægten fra veje-cellen og gemmer det i en variabel, som sendes med til addToGroceryList
       int fd = open("/dev/ttyS0", O_RDONLY);
       ssize_t size = read(fd, &vaegt_name, 1);
       if(vaegt_name == '1')
       {
           wagon.removeFromGroceryList("aeble");
       }
       else if(vaegt_name == '2')
       {
            wagon.removeFromGroceryList("smoer");
       }
       else if (vaegt_name == '3')
       {
            wagon.removeFromGroceryList("rugbroed");
       }

        // kalder sendGroceryListToGUI(SmartWagon, WS::Hub)
        sendGroceryListToGUI(wagon, hub);

        //vaegt_name = 0;
        close(fd); 
    }
    else if (std::string(message, length) == "showProducts") {
        std::cout << "Prints grocery list" << std::endl;

        // kalder sendGroceryListToGUI(SmartWagon, WS::Hub)
        sendGroceryListToGUI(wagon, hub);
           
    }
    else if (std::string(message, length) == "stop") {
        std::cout << "Terminates Smart Wagon" << std::endl;
        state = "off";

        // sender 0 til /dev/ttyS0 for motor.c
        //int length = 1;
        int fd = open("/dev/ttyS0", O_WRONLY);
        write(fd, "0", 1); 
        close(fd);  
    }
    else
    {
        std::cout << "Unknown command: " << std::string(message, length) << std::endl;
    }
  }
};


int main()
{
  uWS::Hub hub;
  
  SmartWagon wagon;

  // Opretter alle produkter i SmartWagons database
  wagon.addProduct("aeble", 170, 2.50);
  wagon.addProduct("smoer", 500, 17.50);
  wagon.addProduct("rugbroed", 750, 22.00);

  Data d {hub, wagon};
  hub.onMessage(d);
  if (hub.listen(3000)) {
    hub.run();
  }
}