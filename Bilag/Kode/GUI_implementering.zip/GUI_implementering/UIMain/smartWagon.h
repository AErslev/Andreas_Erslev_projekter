#include <iostream>
#include <string>
#include <uWS/uWS.h>
#include <thread>
#include <sstream>
#include <vector>

// Structen Product indeholder kun data, som pr. default er public
struct Product
{
    Product(std::string name, int weight, double price)
    {
        name_ = name;
        weight_ = weight;
        price_ = price;
    }
    std::string name_;
    int weight_;
    double price_;
};


class SmartWagon
{
public:
    SmartWagon();
    // add og remove ift. den indebyggede database med varer i butikken
    void addProduct(std::string name, int weight, double price);
    void removeProduct(std::string name);
    // add og remove ift. indkøbslisten
    void addToGroceryList(std::string name);
    void removeFromGroceryList(std::string name);
    // Henter indkøbslisten, som skal sendes til GUI html
    const std::vector<Product>& getGroceryList() const;
    // Returnerer summen af indkøb
    double totalSum();

private:
    std::vector<Product> productList_;
    std::vector<Product> groceryList_;
};


