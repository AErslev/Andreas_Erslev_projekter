
#include <smartWagon.h>
#include <iostream>
#include <vector>


SmartWagon::SmartWagon(){ // bare default constructor

}


// add og remove ift. den indebyggede database med varer i butikken
void SmartWagon::addProduct(std::string name, int weight, double price){
    Product product(name, weight, price);
    productList_.push_back(product);
    std::cout << "Added product with name: " << product.name_ << ", weight: " << product.weight_ 
                                            << " and price: " << product.price_ << std::endl;
}



void SmartWagon::removeProduct(std::string name){

    for(unsigned long i = 0; i < productList_.size(); i++)
    {
        if(productList_[i].name_ == name)
        {
            productList_.erase(productList_.begin() + i);
            std::cout << "Removed product with name: " << productList_[i].name_ << std::endl;
            // Returnerer når varen er blevet slettet fra produktListen
            return;
        }
    }   
}



// add og remove ift. indkøbslisten
void SmartWagon::addToGroceryList(std::string name){
   
   // Søge efter det produkt som er registreret med "weight" parameteren i productList
    for(unsigned long i = 0; i < productList_.size(); i++)
    {
        if(productList_[i].name_ == name) 
        {
            groceryList_.push_back(productList_[i]);
            std::cout << "Added product to grocery list with name: " << productList_[i].name_ << std::endl;
            // Returnerer når varen er blevet tilføjet til indkøbslisten
            return;
        }
    }
    std::cout << "Error message: no product matches the weight: " << name << "for adding in grocery list" << std::endl; 
}



void SmartWagon::removeFromGroceryList(std::string name){
    
    for(unsigned long i = 0; i < groceryList_.size(); i++)
    {
        if(groceryList_[i].name_ == name) 
        {
            groceryList_.erase(groceryList_.begin() + i);
            std::cout << "Removed product with name: " << groceryList_[i].name_ << std::endl;
            // Returnerer når varen er blevet slettet fra indkøbslisten
            return;
        }
    }
    std::cout << "Error message: no product matches the weight: " << name << " for remove in grocery list"<< std::endl; 
}



// Henter indkøbslisten, som skal sendes til GUI html
const std::vector<Product>& SmartWagon::getGroceryList() const{
    return groceryList_;

}

double SmartWagon::totalSum(){
    // Beregne den total sum af indkøb
    double sum = 0;
    for(unsigned long i = 0; i < groceryList_.size(); i++)
    {
       sum = sum + groceryList_[i].price_;
    }
    // returnere den totale sum
    return sum;  
}