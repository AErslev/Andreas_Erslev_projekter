# RankMe Kento Edition
Rankme plugin for CSGO servers, improved from [benscobie's rankme](https://github.com/benscobie/sourcemod-rankme).  

IF YOU WANT TO UPDATE YOUR RANKME TO MINE, YOU HAVE TO BACKUP YOUR OLD DATABSE, LOAD THIS PLUGIN AND THEN IMPORT YOUR OLD DATABSE.

## Forum Thread
For more info please go here

https://forums.alliedmods.net/showthread.php?p=2467665

## Credits
* [lok1](https://forums.alliedmods.net/showthread.php?t=155621) - Developed the original RankMe plugin that this plugin is based on.
* [benscobie](https://github.com/benscobie/sourcemod-rankme) - This plugin is improved from his version.
* [pracc](http://hlmod.ru/resources/cs-go-rankme-web.132/) - Code of kill assist is edited from his rankme
* [TR1D](https://github.com/TR1D) - Thanks for his Russian translation
* [shanapu](https://github.com/shanapu) - Thanks for his German translation
* [2389736818](https://github.com/2389736818) - Thanks for his Simplified Chinese translation
* [Kxnrl](https://github.com/Kxnrl) - Thanks for his rankme cache
* [CrazyHackGUT](https://github.com/CrazyHackGUT) - Thanks for his optimization.

## Donate
If you apreciate my work, you can donate me via [steam trade offer](https://steamcommunity.com/tradeoffer/new/?partner=52559891&token=ADe-707J)
