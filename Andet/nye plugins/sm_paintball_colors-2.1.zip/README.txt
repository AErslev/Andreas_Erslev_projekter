Paintball colors pack


Description
-----------
    This color pack contains additional colors for paintball plugin.

    Default colors are not included.
    
    http://forums.alliedmods.net/showthread.php?t=107012

Requirements
------------
    sm_paintball 1.2.0+

Credits
-------
    * Thanks to L'In20Cible for Paintball Effects - Version 1.5a
      http://addons.eventscripts.com/addons/view/pb
      Default decals are borrowed from this plugin.

    * Thanks to ZVe for great decals improvement from default colors 
      pack. Custom colors are partialy based on this decals.
      Also thanks to custom colors improvement and adding alpha
      transparency.

    * Thanks to [TsM] Agent Rapist for the 1st set of custom colors.
    
    * Thanks to team.epic | Jokeman for the 2nd set of custom colors.

    * Thanks to Xp3r7 for contacted to custom colors creators 
      and made this colors pack possible.
    
Changelog
---------
    Version 2.1:
        * Colors changed, added alpha transparency. Big thanks to ZVe.
            Black
            Brown
            Dark Green
            Golden Rod
            Medium Slate Blue
            Olive
            Red Orange
            Violet
            
    Version 2.0:
        + Added and changed colors
            Baby Blue
            Black
            Blue
            Brown
            Dark Green
            
            Golden Rod
            Medium Slate Blue
            Olive
            Red
            Red Orange
            
            Violet
            White
            
    Version 1.0:
        + Added colors
            Baby Blue
            Blue
            Lime Green
            Purple
            Red
            
            White            

Preview
-------
    [URL=http://img9.imageshack.us/i/colorspack20preview.jpg/][IMG]http://img9.imageshack.us/img9/3548/colorspack20preview.th.jpg[/IMG][/URL]

    