Description
-----------
    When a 1 versus 1 situation occurs, the plugin will prompt players asking if they want to 
    knife to the death. This plugin does support music during the fight, however I have not 
    included any at this time.

    When the knife fight starts, ALL weapons are stripped, and saved. When the fight has 
    concluded, the winner will get their weapons back.

    The bomb is removed when the knife fight starts, there will be no completing the objective, 
    someone must die! Additionally, the fights won't trigger if the bomb is already planted.

    http://forums.alliedmods.net/showthread.php?t=94572

Configuration
-------------
    sm_knifefight_version           - KnifeFight version.
    
    sm_knifefight_enabled           - Enables or disables the plugin.
                                    (Default: 1)
    sm_knifefight_useteleport       - Use the built in teleport system before the fight. 
                                      This helps ensure that both players find each other quickly. 
                                      The Terrorist will always be teleported to the Counter-Terrorist. 
                                      Additionally, if the players are already close to each other, no 
                                      teleport will take place.
                                    (Default: 1)
                                 
    sm_knifefight_forcefight        - Skips asking the players if they want to knife, 
                                      and forces a 1v1 knife fight.
                                    (Default: 0)
    sm_knifefight_restorehealth     - Restore both players health to 100 prior to fighting.
                                    (Default: 0)
    sm_knifefight_winnerhealth      - The amount of health to give the winner for the next round only.
                                    (Default: 0)
    sm_knifefight_winnermoney       - The amount of extra money to give the winner for the next round only.
                                    (Default: 0)
    sm_knifefight_winnerspeed       - The amount of extra speed given to the winner for the next round only.
                                    (Default: 0)
    sm_knifefight_winnereffects     - Use lightning and sound effects on the winner after the fight.
                                    (Default: 1)
    sm_knifefight_losereffects      - Dissolve losers body using special effects.
                                    (Default: 1)
    sm_knifefight_locatorbeam       - Use locator beam between players if they are far apart.
                                    (Default: 1)
    sm_knifefight_declinesound      - Sound file to use when a player declines to knife fight.
                                    (Default: knifefight/chicken.wav)
    sm_knifefight_fightsongs        - Sound files to play during the knife fight (random).
                                    (Default: none.)
    sm_knifefight_stopmusic         - Stop music when fight is over. Useful when used with GunGame.
                                    (Default: 0)
    sm_knifefight_countdowntimer    - Number of seconds to count down before a knife fight.
                                    (Default: 3)
    sm_knifefight_fightimer         - Number of seconds to allow for knifing. Players get slayed after 
                                      this time limit expires.
                                    (Default: 30)
    sm_knifefight_minplayers        - Minimum number of players before a knife fight will trigger.
                                    (Default: 4)
    
    sm_knifefight_alltalk           - Enable alltalk while knife fight.
                                    (Default: 1)
    sm_knifefight_block             - Enable player blocking (disable sm_noblock) if sm_noblock is enabled while knife fight.
                                    (Default: 0)
                                    
                                    If you are using sm_noblock (http://forums.alliedmods.net/showthread.php?t=91617) 
                                    and want to disable noblock plugin automaticaly
                                    every time knife battle is started and enable noblock when knife battle 
                                    is finished than you should set sm_knifefight_block to 1.
                                    By default this option is disabled, so sm_knifefight will not affect
                                    sm_noblock by default.
                                    
    sm_knifefight_randomkill        - Enable random kill after knife fight time end.
                                    (Default: 0)
    sm_knifefight_beaconsound       - The sound to play when beacon ring shows.
                                    (Default: buttons/blip1.wav)
    sm_knifefight_beaconradius      - Beacon radius.
                                    (Default: 800)
    sm_knifefight_soundprefdefault  - Default sound setting for new users.
                                    (Default: 1)
    sm_knifefight_debug             - Enable debug.
                                    (Default: 0)
    sm_knifefight_botfight          - Allow bot to knife fight with bot.
                                    (Default: 0)
    sm_knifefight_showwinner        - Show winner. 0 - Top left, 1 - Chat.
                                    (Default: 0)
    sm_knifefight_removenewplayer   - Remove player connected when fight is started. 0 - Slay, 1 - Move to spec.
                                    (Default: 0)

    say !kfmenu                     - Show knife fight settings menu.

Requirements
------------
    Counter-Strike: Source
    SourceMod 1.2.1

Installation
------------
    Download the zip file and extract into your /cstrike/ directory.

    Manual Installation:

        * Copy knifefight.smx to /cstrike/addons/sourcemod/plugins/
        * Copy knifefight.phrases.txt to /cstrike/addons/sourcemod/translations/
        * Copy knifefight.sp to /cstrike/addons/sourcemod/scripting/
        * Copy chicken.wav to /cstrike/sound/knifefight/
        * Fight Music goes in /cstrike/sound/ and must be added to your knifefight.cfg file.

    The plugin will automatically create your config (knifefight.cfg) file in: /cstrike/cfg/sourcemod/

Credits
-------
    * Thanks to tigerox for GG4 DEATHMATCH ADDON version 1.2
      http://forums.alliedmods.net/showthread.php?t=87198
      Weapon remove on knife fight start is borrowed from its source.

    * Thanks to Altex and Liam for GunGame:SM plugin
      http://forums.alliedmods.net/showthread.php?t=93977
      Colored top left text and colored chat messages 
      is borrowed from its source.

    * Thanks to XARIUS for 1v1 Knife Fight plugin till version 1.2.1
      http://forums.alliedmods.net/showthread.php?t=77948

    * Thanks to Liam for Weapon Restrictions plugin
      http://forums.alliedmods.net/showthread.php?t=69987
      Weapon remove on item pick up is based on its source.

    * Thanks to dalto for original plugin 
      http://forums.alliedmods.net/showthread.php?t=60254
    
    * Thanks to Schubaal Knifep3n plugin for eventscripts
      http://forums.eventscripts.com/viewtopic.php?t=19090

    * Thanks to FlyingMongoose for the lightning effects.
    
    * Thanks to LDuke for the dissolve effects.

Changelog
---------
    1.3.8:
        * Fixed hint text.

    1.3.7:
        + Added cvar "sm_knifefight_removenewplayer" to move spawned player to spec and not slay 
            him if he spawned when knifefight is started. After that plugin removes weapons 
            that left from that player.
        + Added cvar "sm_knifefight_showwinner" to not show winner in top left but in chat.

    1.3.6:
        * Fixed bug when players can call !kfmenu and start fight 
          even if number of players less then sm_knifefight_minplayers.

    1.3.5:
        + Added cvar sm_knifefight_block to disable noblock when knife fight 
          is started. It's behaviour is similar to sm_knifefight_alltalk.
          If you are using sm_noblock (http://forums.alliedmods.net/showthread.php?t=91617) 
          and want to disable noblock plugin automaticaly
          every time knife battle is started and enable noblock when knife battle 
          is finished than you should set sm_knifefight_block to 1.
          By default this option is disabled, so sm_knifefight will not affect
          sm_noblock by default.
        
    1.3.4:
        * Fixed error:
            L 06/25/2009 - 11:36:28: [SM] Native "IsPlayerAlive" reported: Client 3 is not in game
            L 06/25/2009 - 11:36:28: [SM] Displaying call stack trace for plugin "knifefight.smx":
            L 06/25/2009 - 11:36:28: [SM] [0] Line 1597, knifefight.sp:anelHandler()

    1.3.3:
        + Added sm_knifefight_botfight cvar.
        * Now hostages are removed when knife fight is started.
          It is needed to not allow CT to rescue all hostages
          after knife fight is started.

    1.3.2:
        * Added color to chat messages.
        * Blue color of winner in the left top corner is unreadable. Changed to light blue.
        
    1.3.1:
        * Fixed error when someone left server within 1 second after spawn and 1 vs 1 situation occures and 
          there is a knife fight winner from last round and winner bonuses is on.
            L 06/21/2009 - 17:12:27: [SM] Native "IsClientInGame" reported: Client index 0 is invalid
            L 06/21/2009 - 17:12:27: [SM] Displaying call stack trace for plugin "knifefight.smx":
            L 06/21/2009 - 17:12:27: [SM]    [0]    Line 866, knifefight.sp::ItemsWon()
        
    1.3.0:
        + Added Always Accept Knife Fight and Never Accept Knife Fight in the !kfmenu
        + Added kfmenu option to bring back up the menu thats asks you to knife when there is only 1left on each team.
        * Updated translations.
        * Fixed not to drop knife after player wins knife fight.
        
    1.2.1.12:
        * Fixed bug when fight song started (so isFighting == true) but weapons not removed from players 
          and health not restored and beacons not started.
          It happens when someone left the server sometimes.
          BTW after fight there are loser and winner effects. (so isFighting == true)
        * Added debug support.

    1.2.1.11:
        * Redesigned knifefight settings menu.
        
    1.2.1.10:
        * Fixed not to start knife fight if round has ended (round time is up, hostage rescued).

    1.2.1.9:
        + Added the option to allow users to mute/unmute the knife fight song.
          For saving setting clientprefs is used.
        * Maximum fight songs changed from 6 to 20.
        * sm_knifefight_fightsongs top folder location changed from 
          /cstrike/sound/knifefight/ to /cstrike/sound/.
          Add "knifefight/" to all songs to update your cfg.
        
    1.2.1.8:
        * Fixed:
            L 06/16/2009 - 13:09:58: [SM] Native "IsClientInGame" reported: Client index 0 is invalid
            L 06/16/2009 - 13:09:58: [SM] Displaying call stack trace for plugin "knifefight.smx":
            L 06/16/2009 - 13:09:58: [SM] [0] Line 799, knifefight.sp::ItemsWon()
        * Fixed:
            L 06/16/2009 - 18:25:34: [SM] Native "GetClientTeam" reported: Client index 0 is invalid
            L 06/16/2009 - 18:25:34: [SM] Displaying call stack trace for plugin "knifefight.smx":
            L 06/16/2009 - 18:25:34: [SM]    [0]    Line 1281, knifefight.sp::EventPlayerDeath()
        
    1.2.1.7:
        * Fixed. Previous version does not work.

    1.2.1.6:
        * Fixed bug when someone connects and two alive players left and have not accepted knifefight yet.
          Knife fight has to be canceled.
        
    1.2.1.5:
        + Added removing weapons from entire the map on knife fight start.
          It is useful for players that have cl_autowepswitch set to 1.

    1.2.1.4:
        + Added colored hint text to show winner.
        * Fixed don't kill everyone on round restart.
        * Fixed stupid bug :) (previous version can not load at all!!!)
        
    1.2.1.3:
        * Fixed on item pick up do not give knife and do not remove knife and just remove picked up weapon.
        * Fixes bug.
            L 05/26/2009 - 15:57:20: [SM] Native "ForcePlayerSuicide" reported: Client 13 is not in game
            L 05/26/2009 - 15:57:20: [SM] Displaying call stack trace for plugin "knifefight.smx":
            L 05/26/2009 - 15:57:20: [SM]    [0]    Line 608, knifefight.sp::KillPlayer()
        * Fixed don't drop knifes on map.
        * If sv_alltalk is already turned on then at the end of the fight it should't be turned off.
    
    1.2.1.2:
        * Bug fix for:
            L 05/23/2009 - 02:18:17: [SM] Native "IsPlayerAlive" reported: Client 9 is not in game
            L 05/23/2009 - 02:18:17: [SM] Displaying call stack trace for plugin "knifefight.smx":
            L 05/23/2009 - 02:18:17: [SM]    [0]    Line 921, knifefight.sp::VerifyConditions()
            
    1.2.1.1:
        * Bug fix for:
            L 05/11/2009 - 17:58:26: [SM] Native "IsPlayerAlive" reported: Client 5 is not in game
            L 05/11/2009 - 17:58:26: [SM] Displaying call stack trace for plugin "knifefight.smx":
            L 05/11/2009 - 17:58:26: [SM]    [0]    Line 1092, knifefight.sp::PanelHandler()
        * When knifefight time is over check players health and kill only player with minimun health 
          or both if players has equal health.
        + added sm_knifefight_beaconradius - radius of the beacon
        + added sm_knifefight_beaconsound - sound file for the beacon
        * changed beacon effect (g_beamsprite), now it just like in knifep3n (materials/sprites/lgtning.vmt)
        * start beacon sounds in different moments for players
        + sm_knifefight_alltalk - enable alltalk when knifefight is started 
        + sm_knifefight_randomkill - random players kill sequence if knife fight time ended. 
          Usefull for gungame beacause only first killed player lost level.
        * Redesigned menu panel.
        * Commented hookusermessage due to bug (server crash on plugin unload)
          So intermission check is disabled.
            
    1.2.1: 
        * This is original version of 1v1 Knife Fight by XARIUS.
        
TODO
----
    * Feature request:
        1) Can you make it possible to set how much health players get for a 
        knifefight, instead of just giving them 100? On one of my servers we'
        ve always had players get 120 hp for knife fights, so that it takes 
        3 hits (1 left click and 2 right) for a kill.

        2) It would also be very nice if you could make it so that players 
        have a time limit to vote yes or no, and if they havent voted before 
        the timer expires then have them automatically vote yes or no 
        (configurable would be great). Reason being lotta people who dont 
        want to vote yes, will just leave the menu open rather then voting 
        no. In cases like that, the player who voted yes often gets shot up 
        while waiting for the other player to accept..
    * Improvement:
        Is it possible the edit the the sm_knifefight_block cvar so it block all 
        no-block plugins not only your sm_noblock plugin?
    * Bug report:
        if they get teleported than the models get togehter and nobody cant move 
        Need to do: before teleport enable noblock, then teleport, then disable noblock after 
        they have distance, than begin countdown.
    * Weapons disapeares after knife fight.
    * Bug report:
        L 08/14/2010 - 0123: [SM] Native "SlapPlayer" reported: Client 0 is not valid
        L 08/14/2010 - 0123: [SM] Displaying call stack trace for plugin "knifefight.smx":
        L 08/14/2010 - 0123: [SM] [0] Line 587, knifefight.sp::SlapTimer()
    * Improvement:
        When there are seconds left to end the round, there are two guys left on 
        each side and the fight starts, they get slayed and their weapons are 
        being taken, but they had like 5 seconds to fight, so it wasn't possible
        to kill each other.

        Is it possible to prevent situation like this? I mean by letting it end 
        the knife fight if it reaches the round time limit or maybe if it's not 
        possible try maybe to prevent starting the knife fight when there is 
        like 10 seconds to reach round time limit.
    * Feature request:
        There is a plugin to throw the knife...
        But the problem is at a 1 vs 1 fight with the knife, it is not very senseful 
        to throw the knife...

        It is possible to set "sm_throwingknives_enable 0" when the knifefight start, 
        and "sm_throwingknives_enable 1" at the end of the knifefight?

        greetings gaissi

        P.S. Other person would need this function too.

        Look at this post:

        Quote:
        Originally Posted by Xp3r7 View Post
            Awesome, thanks for the quick fix man!

            Another thing people are telling me is that there is a delay/lag/glitch 
            when you run over a thrown knife.

            Like if you run over one on the ground, you lag for just a sec.

            Also, I use a kinifefight plugin to have a dual when it comes down to 
            a 1v1 situation.

            Is there a way to disable the throwing knife when the knifefight happens 
            and re-enable it after its done?

            It seems to be a popular plugin as there is an older version HERE he based 
            it off of so Im probably not the only one wanting this either. 
    * Enable HookUserMessage after fix for https://bugs.alliedmods.net/show_bug.cgi?id=3817
    * After a little more testing i found out that the sound is actually emitting
      from a set place in the maps usually around the center of the entire map
      instead of emitting from the character.
      It is needed to test. I had the same on city_advanced. I think it is
      because of soundscapes. It does not look like a bug, elseware it was not worked on other maps.
    * Rename version variable
    * Feature request
        I think it'd be really awesome if you could like set the teleport places for
        the last two.
        I'm just thinking like say if you are on a surf map like Great River you cold
        tele port them to oposite sides of jail.
        Just an idea, and it'd be cool to see that. 
    * Bug report:
        I found a little problem with your string for the knifefight music.
        Its only 64 in length so if you have long songnames it cuts off after 64.
        I hope you dont mind but I upped it to 256 and recompiled it for my server. 
        Just thought that I might point this out to you. 
    * Feature request:
        Beam only stays on for a few seconds. It should stay on until they are face to
        face and it should come back on if they move apart. People like to run away
        from knifes on my server.
    * Feature request:
        hi can u add a cvar that i configure the amount of health that players have
        when the KF starts? i wish to set it on 150 HP
    * If someone spawn when knifefight is in progress not slay him, but just do not
      allow him to spawn. See example in antirejoin plugin.
    * ������� ����� ��� � ���� ������ �� ����� ���� �������� "������ ��" �
      "������ ���", ������� �� 5 � 6 ���� �� ��������� �� ����
      ��� �� ���� �������� ����� ���� ��������
      ������ ���� �� "������ ��", � "�� �� ����� �����"
    * ������� ���������� �������.        
    * ������� ���������� ������� �� ����������.        
    * �������� ������ ������ �� ������. ���� ���-�� ������� �������.
      �������� ���������� ����� �� ����� ��� ����������.
    * ������ ����� ����������� � 256 �������� �� ��� ������� � �������. ����� ������� ��
      ����� ����������� ��������.
    * Bugreport: ���� �� ����� ������� ������������� knifefight, �� ����� ��� restart,
        ��������� ������������� ������, �� alltalk ������� ����������.
    * Bugreport: ���� ������� ����� � ����� ������������ �� knifefight, �� ��� �� �����.
        ������������� ����� ���:
            1) ����� �����
            2) ������� ����
            3) ����� ����������
            4) ��� ���������� ������ ����� 5 ������ ��������
    * bug:
        Hi, Im working on making a server that will run L.Duke's Vip Mod, and thought it be nice 
        to include your Knife Fight Plugin for when the Vip wants to have a fair fight +P

        Well ran the server and tested the plugin with bots, made my self the vip, and when it 
        came down to a 1v1 situation bot ask me if I wanted to fight I aid yes....

        Well unfortunately the bot was allowed to have a knife and the Vip was strip of his 
        knife so ended out me changing my name to Jerry and the bots name to Tom +P

        If you can please add support for the vip model as well.

        P.S. I dont know if the below information would help or not but I figured this may give 
        you a good idea as to why the vip doesnt get a knife during a knife fight thanks +)

        pVIP: 10010060
        pVipUsp: 0C55DE00
    + Feature request: it is possible to make so the last 2 player has 5 seconds to respond 
        to the knife vote after that the vote will go away and they can not vote any more?
        ex sm_knifefight_replytime 5

