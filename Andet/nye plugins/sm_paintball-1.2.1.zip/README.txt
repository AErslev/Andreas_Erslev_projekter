Paintball


Description
-----------
    This plugin adds paintball decals to bullet impacts.
    
    By default you can get about 100 paintball decals at once on the map.
    But if you want to increase this limit you should type in client(!) 
    console "mp_decals 2000" (thats will be about 1000 paintball decals).

    http://forums.alliedmods.net/showthread.php?t=107012

Cvars and commands
------------------
    sm_paintball_version        - Paintball Version
    sm_paintball_prefdefault    - Default setting for new users. (Default: 1)

    say !paintball              - Show paintball settings menu.
    

Requirements
------------
    Counter-Strike: Source
    SourceMod 1.2.0+
    clientprefs plugin from SourceMod

Credits
-------
    * Thanks to L'In20Cible for Paintball Effects - Version 1.5a
      http://addons.eventscripts.com/addons/view/pb
      Decals are borrowed from this plugin.

    * Thanks to ZVe for great decals improvement.

Changelog
---------
    Version 1.2.1:
        * Fixed green decal. Actualy it was orange because of bug in pb_green.vmt file.
    
    Version 1.2.0:
        + Added config file addons/sourcemod/configs/paintball.cfg
          to let people add any colors by themselfs without recompiling plugin.
          Now you can disable particular colors or add your own colors.
    
    Version 1.1:
        * Fixed
            L 10/21/2009 - 23:13:38: [SM] Native "TE_Send" reported: Client 15 is not connected
            L 10/21/2009 - 23:13:38: [SM] Displaying call stack trace for plugin "paintball.smx":
            L 10/21/2009 - 23:13:38: [SM]   [0]  Line 95, paintball.sp::Event_BulletImpact()
        
    Version 1.0:
        * First release
    
Todo
----

