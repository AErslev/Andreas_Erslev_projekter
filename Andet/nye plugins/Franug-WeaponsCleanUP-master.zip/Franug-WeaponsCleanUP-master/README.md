# Franug-WeaponsCleanUP

https://forums.alliedmods.net/showthread.php?p=1424937
